DROP SCHEMA IF EXISTS info_db;

CREATE SCHEMA info_db;
USE info_db;

CREATE TABLE user(
	userName VARCHAR(25) not null,
    passwrd VARCHAR(25) not null
);