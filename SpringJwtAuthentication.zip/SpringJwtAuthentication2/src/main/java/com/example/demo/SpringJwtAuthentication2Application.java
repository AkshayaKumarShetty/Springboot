package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJwtAuthentication2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringJwtAuthentication2Application.class, args);
	}

}
