package com.personal.data;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonalDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
