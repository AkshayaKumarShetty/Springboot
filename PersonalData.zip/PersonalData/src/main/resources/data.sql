DROP SCHEMA IF EXISTS data_db;

CREATE SCHEMA data_db;
USE data_db;

CREATE TABLE user(
	firstname VARCHAR(25) not null,
    lastname VARCHAR(25) not null,
	dateofbirth VARCHAR(25) not null,
	gender VARCHAR(25) not null,
    email VARCHAR(25) not null,
    mobileno VARCHAR(25) not null,
    address VARCHAR(25) not null,
    city VARCHAR(25) not null,
    state VARCHAR(25) not null,
    country VARCHAR(25) not null,
    pin VARCHAR(25) not null,
    CONSTRAINT ps_mobileno_pk PRIMARY KEY (mobileno)
);

Drop table user;