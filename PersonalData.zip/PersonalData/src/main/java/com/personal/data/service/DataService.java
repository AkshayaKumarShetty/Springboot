package com.personal.data.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.personal.data.model.Data;
import com.personal.data.repo.DataRepo;

@Service
public class DataService
{
	@Autowired
	private DataRepo dataRepo;
	
	public String store(Data d)
	{
		return dataRepo.addData(d);
	}
	
	public List<Data> getAll()
	{
		return dataRepo.getData();
	}
}
