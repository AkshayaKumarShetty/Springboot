package com.personal.data.repo;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Repository;

import com.personal.data.model.Data;

@Repository
public class DataRepo
{
	private List<Data> dataList;
	
	public DataRepo()
	{
		dataList = new ArrayList<>();
	}
	
	public String addData(Data d)
	{
		dataList.add(d);
		return d.getLastname()+ " " +d.getFirstname();
	}
	
	public List<Data> getData()
	{
		List<Data> d = dataList.stream().collect(Collectors.toList());
		return d;
	}
	
	public List<Data> getDataList() {
		return dataList;
	}

	public void setDataList(List<Data> dataList) {
		this.dataList = dataList;
	}
}
