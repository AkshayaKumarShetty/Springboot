package com.personal.data;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersonalDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(PersonalDataApplication.class, args);
	}

}

