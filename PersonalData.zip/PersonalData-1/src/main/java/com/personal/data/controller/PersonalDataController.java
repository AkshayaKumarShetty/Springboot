package com.personal.data.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.personal.data.entity.DataEntity;
import com.personal.data.service.DataService;

@RestController
@RequestMapping("/data")
public class PersonalDataController
{
	@Autowired
	DataService dataService;
	
	@GetMapping("/hi")
	public String Hi()
	{
		return "AA007";
	}
	
	@PostMapping("/store")
	public ResponseEntity<DataEntity> store(@RequestBody DataEntity d)
	{
		DataEntity id = dataService.store(d);
		return new ResponseEntity<DataEntity>(id, HttpStatus.CREATED);
	}
	
	@GetMapping("/getAll")
	public ResponseEntity<List<DataEntity>> getAllData()
	{
		List<DataEntity> d = dataService.getAll();
		return new ResponseEntity<List<DataEntity>>(d, HttpStatus.OK);
	}
}
