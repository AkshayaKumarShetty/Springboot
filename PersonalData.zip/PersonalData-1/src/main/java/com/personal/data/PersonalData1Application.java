package com.personal.data;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersonalData1Application {

	public static void main(String[] args) {
		SpringApplication.run(PersonalData1Application.class, args);
	}

}
