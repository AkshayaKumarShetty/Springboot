package com.personal.data.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.personal.data.entity.DataEntity;

public interface DataRepos extends JpaRepository<DataEntity, String>
{
	
}
