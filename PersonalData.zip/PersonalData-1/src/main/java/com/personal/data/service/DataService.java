package com.personal.data.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.personal.data.entity.DataEntity;
import com.personal.data.repo.DataRepos;

@Service
public class DataService
{
	@Autowired
	private DataRepos dataRepos;
	
	public DataEntity store(DataEntity d)
	{
		return dataRepos.save(d);
	}
	
	public List<DataEntity> getAll()
	{
		return dataRepos.findAll();
	}
}
