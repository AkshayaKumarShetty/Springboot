package com.personal.data.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import com.personal.data.model.Data;

@Entity
public class DataEntity
{
	private String firstname;
	private String lastname;
	private String dateofbirth;
	private String gender;
	private String email;
	@Id
	private String mobileno;
	private String address;
	private String city;
	private String state;
	private String country;
	private String pin;
	
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getDateofbirth() {
		return dateofbirth;
	}
	public void setDateofbirth(String dateofbirth) {
		this.dateofbirth = dateofbirth;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getPin() {
		return pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
	
	public static Data convertToData(DataEntity dataEntity)
	{
		Data data = new Data();
		data.setFirstname(dataEntity.getFirstname());
		data.setLastname(dataEntity.getLastname());
		data.setDateofbirth(dataEntity.getDateofbirth());
		data.setGender(dataEntity.getGender());
		data.setEmail(dataEntity.getEmail());
		data.setMobileno(dataEntity.getMobileno());
		data.setAddress(dataEntity.getAddress());
		data.setCity(dataEntity.getCity());
		data.setState(dataEntity.getState());
		data.setCountry(dataEntity.getCountry());
		data.setPin(dataEntity.getPin());
		return data;
	}
}
